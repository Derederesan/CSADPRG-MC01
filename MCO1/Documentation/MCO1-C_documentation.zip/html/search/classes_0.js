var searchData=
[
  ['currency_0',['Currency',['../struct_currency.html',1,'']]]
];
