var annotated_dup =
[
    [ "Currency", "struct_currency.html", null ]
];